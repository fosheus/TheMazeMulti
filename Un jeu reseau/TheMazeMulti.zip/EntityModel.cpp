#include "EntityModel.h"

EntityModel::EntityModel(sf::Uint16 id,float x,float y,sf::Uint16 score)
{
	this->id = id;
	this->x = x;
	this->y = y;
	this->score = score;
}



void EntityModel::setId(sf::Uint16 id)
{
	this->id = id;
}


void EntityModel::setX(float x)
{
	this->x = x;
}

void EntityModel::setY(float y)
{
	this->y = y;
}

sf::Uint16 EntityModel::getId() const
{
	return this->id;
}

float EntityModel::getX() const
{
	return this->x;
}

float EntityModel::getY() const
{
	return this->y;
}

void EntityModel::setName(sf::String name)
{
	this->name = name;
}

void EntityModel::setScore(sf::Uint16 score)
{
	this->score = score;
}

sf::String EntityModel::getName() const
{
	return this->name;
}

sf::Uint16 EntityModel::getScore() const
{
	return score;
}

EntityModel::~EntityModel()
{
}

sf::Packet& operator << (sf::Packet& packet, const EntityModel& em) {
	return packet << em.getId() << em.getX() << em.getY() << em.getScore();
}

sf::Packet& operator >> (sf::Packet& packet, EntityModel& em) {
	sf::Uint16 id;
	float x;
	float y;
	sf::Uint16 score;

	packet >> id >> x >> y >> score;

	em.setId(id);
	em.setX(x);
	em.setY(y);
	em.setScore(score);

	return packet;
}
