#pragma once
#include <SFML\Network.hpp>
#include "IPacketManager.h"
#include "Game.h"
#include <queue>
#include <iostream>
class ClientSocketManager
{
public:
	ClientSocketManager(GameDataRef data,IPacketManager* packetManager,std::string address,unsigned short port);
	bool connect();
	void sendPacket(sf::Packet& packet);
	void close();
	void receive();
	void sendWaitingPackets();
	~ClientSocketManager();

private :

	void closeAll();

private :

	const int MAX_TIMEOUT = 20;
	int timeoutCount;
	GameDataRef _data;
	IPacketManager* packetManager;

	sf::IpAddress address;
	short port;
	sf::TcpSocket socket;


	std::queue<sf::Packet> dataToSend;
	std::queue<sf::Packet> notSentPackets;

};

