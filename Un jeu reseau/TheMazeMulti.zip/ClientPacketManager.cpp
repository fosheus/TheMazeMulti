#include "ClientPacketManager.h"

ClientPacketManager::ClientPacketManager(GameDataRef data, IClientCallback * client,std::string address, unsigned short port) : _data(data),socketManager(data,this,address,port)
{
	this->client = client;
}

ClientPacketManager::~ClientPacketManager()

{
}

bool ClientPacketManager::connect()
{
	return socketManager.connect();
}


void ClientPacketManager::disconnect()
{
	socketManager.close();
}

void ClientPacketManager::packetReceived(sf::Packet & packet)
{
	sf::Uint8 code;
	packet >> code;
	switch (code)
	{
	case Common::WELCOME:
		client->welcomed(welcomeReceived(packet));
		break;
	case Common::ENTITYPOS:
		client->updateEntityModel(entityPosReceived(packet));
		break;
	case Common::STARTGAME:
		client->startGame();
		break;
	case Common::GENERATELEVEL:
		client->generateLevel(generateLevelReceived(packet));
		break;
	case Common::LEVELCOMPLETED:
		client->levelCompleted(levelCompletedReceived(packet));
		break;
	case Common::DISCONNECT:
		client->removeEntity(disconnectReceived(packet));
		break;
	case Common::NAME:
		client->updateEntityName(nameReceived(packet));
		break;
	case Common::NEWGAME:
	case Common::EVENT:
	case Common::LEVELGENERATED :
		std::cout << "unimplemented packet received " + std::to_string(code) << std::endl;
		break;
	default:
		std::cout << "undefined packet received " + std::to_string(code) << std::endl;
		break;
	}
}

void ClientPacketManager::sendEntityModel(EntityModel & em)
{
	sf::Packet packet;
	packet << (sf::Uint8)Common::ENTITYPOS;
	packet << em;
	socketManager.sendPacket(packet);
}

void ClientPacketManager::receivePackets(sf::Uint16 id)
{
	socketManager.receive();
}

void ClientPacketManager::sendWaitingPackets()
{
	socketManager.sendWaitingPackets();
}

void ClientPacketManager::startGame(sf::Uint16 id)
{
	sf::Packet packet;
	sf::Uint8 code = Common::NEWGAME;
	packet << code << id;
	socketManager.sendPacket(packet);

}

void ClientPacketManager::sendName(sf::Uint16 id, sf::String name)
{
	sf::Packet packet;
	sf::Uint8 code = Common::NAME;
	packet << code << id << name;
	socketManager.sendPacket(packet);
}

sf::Uint16 ClientPacketManager::welcomeReceived(sf::Packet & packet)
{
	sf::Uint16 id;
	packet >> id;
	return id;
}

std::vector<EntityModel> ClientPacketManager::entityPosReceived(sf::Packet & packet)
{
	std::vector<EntityModel> entities;
	EntityModel em;
	while (!packet.endOfPacket()) {
		packet >> em;
		entities.push_back(em);
	}
	return entities;
}

int ClientPacketManager::newGameReceived(sf::Packet & packet)
{
	return 0;
}

void ClientPacketManager::startGameReceived(sf::Packet & packet)
{

}

int ClientPacketManager::eventReceived(sf::Packet & packet)
{
	return 0;
}

MazeConfig ClientPacketManager::generateLevelReceived(sf::Packet & packet)
{
	MazeConfig config;
	packet >> config;
	return config;
}


int ClientPacketManager::disconnectReceived(sf::Packet & packet)
{
	sf::Uint16 id;
	packet >> id;
	return id;
}

void ClientPacketManager::lostConnection()
{
	client->lostConnection();
}

std::pair<sf::Uint16, sf::String> ClientPacketManager::nameReceived(sf::Packet & packet)
{
	sf::Uint16 id;
	sf::String name;
	packet >> id >> name;
	return std::pair<sf::Uint16, sf::String>(id, name);
}

sf::Uint16 ClientPacketManager::levelCompletedReceived(sf::Packet & packet)
{
	sf::Uint16 id;
	packet >> id;
	return id;
}

int ClientPacketManager::levelGeneratedReceived(sf::Packet & packet)
{
	return 0;
}

