#include "ClientSocketManager.h"


ClientSocketManager::ClientSocketManager(GameDataRef data, IPacketManager * packetManager, std::string address, unsigned short port):_data(data)
{
	this->packetManager = packetManager;
	this->address = address;
	this->port = port;
	timeoutCount = 0;
}

bool ClientSocketManager::connect()
{
	if (this->socket.connect(address,port) != sf::Socket::Done) {
		return false;
	}
	socket.setBlocking(false);

	return true;
}


void ClientSocketManager::sendPacket(sf::Packet& packet)
{
	dataToSend.push(packet);
}


void ClientSocketManager::close()
{
	closeAll();
}

void ClientSocketManager::receive()
{
	sf::Packet packet;
	sf::Socket::Status status;

	if (socket.getLocalPort() != 0) {

		status = socket.receive(packet);
		if (status == sf::Socket::Done) {
			//ok
			packetManager->packetReceived(packet);
		}
		else if (status == sf::Socket::NotReady) {
			//std::cout << "Stream not ready" << std::endl;
		}
		else if (status == sf::Socket::Error) {
			std::cout << "Error while sending data" << std::endl;
		}
		else if (status == sf::Socket::Disconnected) {
			std::cout << "Disconnected from remote system" << std::endl;
			packetManager->lostConnection();
		}
	}

}

void ClientSocketManager::sendWaitingPackets() {
	sf::Packet packet;
	sf::Socket::Status status;
	if (socket.getLocalPort() != 0) {

		int nb = dataToSend.size();
		int i = 0;
		while (i < nb) {
			packet = dataToSend.front();
			status = socket.send(packet);
			if (status == sf::Socket::Done) {
				//ok
			}
			else if (status == sf::Socket::NotReady || status == sf::Socket::Partial) {
				//std::cout << "Stream not ready" << std::endl;
				dataToSend.push(packet);
			}
			else if (status == sf::Socket::Error) {
				std::cout << "Error while sending data" << std::endl;
				dataToSend.push(packet);
			}
			else if (status == sf::Socket::Disconnected) {
				std::cout << "Disconnected from remote system" << std::endl;
				packetManager->lostConnection();
			}
			dataToSend.pop();
			i++;
		}
	}
}


ClientSocketManager::~ClientSocketManager()
{
}




void ClientSocketManager::closeAll()
{
	
	this->socket.disconnect();
}

