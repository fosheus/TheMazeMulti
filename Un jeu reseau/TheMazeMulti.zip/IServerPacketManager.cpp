#include "IServerPacketManager.h"

void IServerPacketManager::lostConnection()
{
}

std::pair<sf::Uint16, sf::String> IServerPacketManager::nameReceived(sf::Packet & packet)
{
	return std::pair<sf::Uint16, sf::String>();
}
