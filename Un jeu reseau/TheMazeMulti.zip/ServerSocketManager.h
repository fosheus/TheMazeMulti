#pragma once
#include <SFML\Network.hpp>
#include "Game.h"
#include "Common.h"
#include "IServerPacketManager.h"
#include <queue>
class ServerSocketManager
{
private:

	const int MAX_TIMEOUT = 20;
	enum ServerStatus {
		LOBBY,
		RUNNING,
		END
	};

public:
	ServerSocketManager(GameDataRef data, IServerPacketManager* packetManager, int port);
	~ServerSocketManager();

	void startServer();
	void stopServer();
	/**
	sends packet to indicated client, or broadcast if 0
	*/
	void sendPacket(sf::Uint16 id, sf::Packet& packet);

	void receivePackets();
	void sendWaitingPackets();

private :

	bool handleSocket(sf::Uint16 id, sf::TcpSocket* socket);


private:
	GameDataRef _data;

	unsigned short port;
	IServerPacketManager* packetManager;
	sf::SocketSelector selector;
	sf::TcpListener listener;
	std::queue<std::pair<sf::Uint16, sf::Packet>> packetsToSend;
	std::map<sf::Uint16, sf::TcpSocket*> clients;
	
	bool started;

};

