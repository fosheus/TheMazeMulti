#include "ServerSocketManager.h"
#include <iostream>

ServerSocketManager::ServerSocketManager(GameDataRef data, IServerPacketManager * packetManager, int port) : _data(data)
{
	this->port = port;
	this->packetManager = packetManager;
	listener.setBlocking(false);
}


ServerSocketManager::~ServerSocketManager()
{

}

void ServerSocketManager::startServer()
{
	started = true;
	listener.listen(this->port);
}

void ServerSocketManager::stopServer()
{
	listener.close();
	started = false;
}

void ServerSocketManager::sendPacket(sf::Uint16 id, sf::Packet& packet)
{
	this->packetsToSend.push(std::pair<sf::Uint16, sf::Packet>(id, packet));
}

void ServerSocketManager::receivePackets()
{
	if (started) {
		std::map<sf::Uint16, sf::TcpSocket*>::iterator it;

		sf::TcpSocket * client = new sf::TcpSocket();
		if (listener.accept(*client) == sf::Socket::Done) {
			sf::Uint16 id;
			id = packetManager->handleNewClient();
			if (id > 0) {
				std::cout << "client accepted " + client->getRemoteAddress().toString() << std::endl;
				clients[id] = client;
				client->setBlocking(false);
			}
			else {
				delete client;
			}
		}
		else {
			delete client;
		}
		for (it = clients.begin(); it != clients.end(); ++it)
		{
			if (!handleSocket(it->first, it->second)) {
				delete clients[it->first];
				it = clients.erase(it);

				break;
			}
		}
	}
}

void ServerSocketManager::sendWaitingPackets()
{
	std::map<sf::Uint16, sf::TcpSocket*>::iterator it;
	std::pair<sf::Uint16, sf::Packet> packet;
	sf::Socket::Status status;
	if (started) {
		int nb = packetsToSend.size();
		int i = 0;
		while (i < nb) {
			packet = packetsToSend.front();
			if (packet.first == 0) {
				//broadcast
				for (it = clients.begin(); it != clients.end(); it++)
				{
					status = it->second->send(packet.second);
					if (status == sf::Socket::Done) {

					}
					else if (status == sf::Socket::NotReady || status == sf::Socket::Partial) {
						packetsToSend.push(packet);
					}
					else if (status == sf::Socket::Error) {
						std::cout << "Error while sending packet to client " + std::to_string(it->first) << std::endl;
					}
					else if (status == sf::Socket::Disconnected) {
						std::cout << "Client lost connection " + std::to_string(it->first) << std::endl;
						packetManager->clientLostConnection(it->first);
						delete it->second;
						it = clients.erase(it);
					}
				}

			}
			else {
				//send to specific client
				status = clients[packet.first]->send(packet.second);
				if (status == sf::Socket::Done) {

				}
				else if (status == sf::Socket::NotReady || status == sf::Socket::Partial) {
					packetsToSend.push(packet);
				}
				else if (status == sf::Socket::Error) {
					std::cout << "Error while sending packet to client " + std::to_string(it->first) << std::endl;
				}
				else if (status == sf::Socket::Disconnected) {
					std::cout << "Client lost connection " + std::to_string(it->first) << std::endl;
					packetManager->clientLostConnection(it->first);
					delete it->second;
					it = clients.erase(it);
				}

			}
			packetsToSend.pop();
			i++;
		}
	}

}


bool ServerSocketManager::handleSocket(sf::Uint16 id,sf::TcpSocket* socket)
{
	sf::Packet packet;
	sf::Socket::Status status;

	status = socket->receive(packet);
	if (status == sf::Socket::Done) {
		packetManager->packetReceived(packet);
	}
	else if (status == sf::Socket::NotReady) {
		//not ready
	}
	else if (status == sf::Socket::Error) {
		std::cout << "Error while receiving from client " + std::to_string(id) << std::endl;
	}
	else if (status == sf::Socket::Disconnected) {
		std::cout << "Disconnection from remote client " + std::to_string(id) << std::endl;
		packetManager->clientLostConnection(id);
		return false;
	}
	return true;
}