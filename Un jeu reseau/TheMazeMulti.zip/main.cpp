#include "Game.h"
#include "DEFINITIONS.h"
int main()
{
	Game(SCREEN_WIDTH, SCREEN_HEIGHT, "SFML WORKS");

	return EXIT_SUCCESS;
}