#pragma once
#include "Common.h"
#include "IPacketManager.h"
#include "Game.h"
#include "IServerCallback.h"
#include "ServerSocketManager.h"
#include <iostream>
class ServerPacketManager :
	public IServerPacketManager
{
public:
	ServerPacketManager(GameDataRef data,IServerCallback* server,unsigned short port);
	

	void startServer();
	void stopServer();

	void handleClients();

	void broadcastEntityModel(EntityModel & em);
	void broadcastLevelCompleted(sf::Uint16 id);
	void sendSeedDimension(MazeConfig config);
	void broadcastName(sf::Uint16 id, sf::String name);

	~ServerPacketManager();

private :

	// H�rit� via IPacketManager
	virtual sf::Uint16 welcomeReceived(sf::Packet & packet) override;

	virtual std::vector<EntityModel> entityPosReceived(sf::Packet & packet) override;

	virtual int newGameReceived(sf::Packet & packet) override;

	virtual void startGameReceived(sf::Packet & packet) override;

	virtual int eventReceived(sf::Packet & packet) override;

	virtual int levelGeneratedReceived(sf::Packet & packet) override;

	virtual int disconnectReceived(sf::Packet & packet) override;


	// H�rit� via IPacketManager
	virtual MazeConfig generateLevelReceived(sf::Packet & packet) override;

	virtual sf::Uint16 levelCompletedReceived(sf::Packet & packet) override;

	virtual void packetReceived(sf::Packet & packet) override;
	virtual int handleNewClient() override;

	// H�rit� via IServerPacketManager
	virtual void clientLostConnection(sf::Uint16 id) override;
	
private :
	GameDataRef _data;
	IServerCallback* server;
	ServerSocketManager socketManager;




	// H�rit� via IServerPacketManager
	virtual sf::Uint16 getNextClientId() override;


	// H�rit� via IServerPacketManager
	virtual void lostConnection() override;


	// H�rit� via IServerPacketManager
	virtual std::pair<sf::Uint16, sf::String> nameReceived(sf::Packet & packet) override;

};

