#pragma once
#include "Common.h"
#include "ClientSocketManager.h"
#include "IPacketManager.h"
#include "IClientCallback.h"
class ClientPacketManager : public IPacketManager
{
public:
	ClientPacketManager(GameDataRef data,IClientCallback* client,std::string address, unsigned short port);
	~ClientPacketManager();
	bool connect();
	void disconnect();
	virtual void packetReceived(sf::Packet & packet) override;
	void sendEntityModel(EntityModel& em);
	void receivePackets(sf::Uint16 id);
	void sendWaitingPackets();
	void startGame(sf::Uint16 id);
	void sendName(sf::Uint16 id, sf::String name);


private: 
	GameDataRef _data;
	ClientSocketManager socketManager;
	IClientCallback* client;



	// H�rit� via IPacketManager
	virtual sf::Uint16 welcomeReceived(sf::Packet & packet) override;

	virtual std::vector<EntityModel> entityPosReceived(sf::Packet & packet) override;

	virtual int newGameReceived(sf::Packet & packet) override;

	virtual void startGameReceived(sf::Packet & packet) override;

	virtual MazeConfig generateLevelReceived(sf::Packet & packet) override;

	virtual int eventReceived(sf::Packet & packet) override;

	virtual sf::Uint16 levelCompletedReceived(sf::Packet & packet) override;

	virtual int levelGeneratedReceived(sf::Packet & packet) override;

	virtual int disconnectReceived(sf::Packet & packet) override;

	virtual void lostConnection() override;


	// H�rit� via IPacketManager
	virtual std::pair<sf::Uint16, sf::String> nameReceived(sf::Packet & packet) override;

};

