#pragma once
#include <SFML\Graphics.hpp>
#include <SFML\Network.hpp>

class EntityModel
{
public:
	EntityModel(sf::Uint16 id,float x,float y,sf::Uint16 score);
	EntityModel() {}
	void setId(sf::Uint16 id);
	void setX(float x);
	void setY(float y);
	void setName(sf::String name);
	void setScore(sf::Uint16 score);
	sf::Uint16 getId() const;
	float getX() const;
	float getY() const;
	sf::String getName() const;
	sf::Uint16 getScore() const;


	~EntityModel();

private :
	float x;
	float y;
	sf::Uint16 id;
	sf::String name;
	sf::Uint16 score;
};



sf::Packet& operator << (sf::Packet& packet, const EntityModel& em);

sf::Packet& operator >> (sf::Packet& packet, EntityModel& em);
