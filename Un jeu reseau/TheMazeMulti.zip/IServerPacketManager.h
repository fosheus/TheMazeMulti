#pragma once
#include "IPacketManager.h"
class IServerPacketManager :
	public IPacketManager
{
public:

	// H�rit� via IPacketManager
	virtual void packetReceived(sf::Packet & packet) override = 0;
	virtual int handleNewClient() = 0;
	virtual void clientLostConnection(sf::Uint16 id) = 0;
	virtual sf::Uint16 getNextClientId() = 0;

private :

	virtual sf::Uint16 welcomeReceived(sf::Packet & packet) override = 0;
	virtual std::vector<EntityModel> entityPosReceived(sf::Packet & packet) override = 0;
	virtual int newGameReceived(sf::Packet & packet) override = 0;
	virtual void startGameReceived(sf::Packet & packet) override = 0;
	virtual MazeConfig generateLevelReceived(sf::Packet & packet) override = 0;
	virtual int eventReceived(sf::Packet & packet) override = 0;
	virtual sf::Uint16 levelCompletedReceived(sf::Packet & packet) override = 0;
	virtual int levelGeneratedReceived(sf::Packet & packet) override = 0;
	virtual int disconnectReceived(sf::Packet & packet) override = 0;
	virtual std::pair<sf::Uint16, sf::String> nameReceived(sf::Packet & packet) override = 0;

	

	// H�rit� via IPacketManager
	virtual void lostConnection() override;



};

