#pragma once
#include "ServerPacketManager.h"
#include "IServerCallback.h"
#include "Maze.h"

class GameServer :public IServerCallback
{
public:
	GameServer(GameDataRef data,int port );
	~GameServer();

	void startServer();
	void stopServer();
	void update(float dt);

private:
	// H�rit� via IServerCallback
	virtual EntityModel* newClientConnected() override;
	virtual bool entityModel(EntityModel & em) override;
	virtual bool removeClient(sf::Uint16 id) override;
	virtual bool newGame(sf::Uint16 id) override;
	virtual bool levelGenerated(sf::Uint16 id) override;
	virtual EntityModel* getEntityModelById(sf::Uint16 id) override;
	// H�rit� via IServerCallback
	virtual sf::Uint16 getNextEntityId() override;
	virtual std::map<sf::Uint16, EntityModel*> getAllEntities() override;
	// H�rit� via IServerCallback
	virtual void levelCompleted(sf::Uint16 id) override;

	
private :
	GameDataRef _data;
	ServerPacketManager packetManager;
	std::map<sf::Uint16, EntityModel*> entities;
	int indexNextClient;

	Maze maze;
	int level;


	// H�rit� via IServerCallback
	virtual void changeClientName(std::pair<sf::Uint16, sf::String> name) override;

};

