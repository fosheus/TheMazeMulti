#include "ServerPacketManager.h"




ServerPacketManager::~ServerPacketManager()
{
	socketManager.stopServer();
}

ServerPacketManager::ServerPacketManager(GameDataRef data, IServerCallback * server, unsigned short port) :_data(data),socketManager(data,this,port)
{
	this->server = server;
}

void ServerPacketManager::packetReceived(sf::Packet & packet)
{
	sf::Uint8 code;
	packet >> code;
	switch (code)
	{

	case Common::ENTITYPOS:
		server->entityModel(entityPosReceived(packet)[0]);
		break;
	case Common::NEWGAME :
		server->newGame(newGameReceived(packet));
		break;
	
	case Common::LEVELGENERATED:
		server->levelGenerated(levelGeneratedReceived(packet));
		break;
	case Common::NAME : 
		server->changeClientName(nameReceived(packet));
		break;
	case Common::WELCOME:
	case Common::EVENT:
	case Common::GENERATELEVEL:
	case Common::LEVELCOMPLETED:
	case Common::DISCONNECT:
		std::cout << "unimplemented packet received " + std::to_string(code) << std::endl;
		break;
	default:
		std::cout << "undefined packet received " + std::to_string(code) << std::endl;
		break;
	}
}

int ServerPacketManager::handleNewClient()
{
	sf::Packet packet;
	EntityModel* em;
	em = this->server->newClientConnected();
	

	sf::Uint8 code = Common::WELCOME;
	packet << code << em->getId();
	socketManager.sendPacket(em->getId(), packet);

	packet.clear();
	std::map<sf::Uint16, EntityModel*> entities = server->getAllEntities();
	std::map<sf::Uint16, EntityModel*>::iterator it;
	code = Common::ENTITYPOS;
	packet << code;
	for (it = entities.begin(); it != entities.end(); it++) {
		packet << *it->second;
	}
	socketManager.sendPacket(0,packet);
	return em->getId();
}

sf::Uint16 ServerPacketManager::welcomeReceived(sf::Packet & packet)
{
	return sf::Uint16();
}

std::vector<EntityModel> ServerPacketManager::entityPosReceived(sf::Packet & packet)
{
	std::vector<EntityModel> ems;
	EntityModel em;
	while (!packet.endOfPacket()) {
		packet >> em;
		ems.push_back(em);
	}
	return ems;
}

int ServerPacketManager::newGameReceived(sf::Packet & packet)
{
	sf::Uint16 id;
	packet >> id;
	return id;
}

void ServerPacketManager::startGameReceived(sf::Packet & packet)
{
}

int ServerPacketManager::eventReceived(sf::Packet & packet)
{
	return 0;
}

int ServerPacketManager::levelGeneratedReceived(sf::Packet & packet)
{
	return 0;
}

int ServerPacketManager::disconnectReceived(sf::Packet & packet)
{
	return 0;
}

MazeConfig ServerPacketManager::generateLevelReceived(sf::Packet & packet)
{
	return MazeConfig();
}

sf::Uint16 ServerPacketManager::levelCompletedReceived(sf::Packet & packet)
{
	return sf::Uint16();
}

sf::Uint16 ServerPacketManager::getNextClientId()
{
	return server->getNextEntityId();
}

void ServerPacketManager::lostConnection()
{

}


std::pair<sf::Uint16, sf::String> ServerPacketManager::nameReceived(sf::Packet & packet)
{
	std::pair<sf::Uint16, sf::String> ret;
	sf::String name;
	sf::Uint16 id;

	packet >> id >> name;

	ret.first = id;
	ret.second = name;
	return ret;
}

void ServerPacketManager::clientLostConnection(sf::Uint16 id)
{
	server->removeClient(id);
	sf::Packet packet;
	sf::Uint8 code = Common::DISCONNECT;
	packet << code << id;
	socketManager.sendPacket(0, packet);

}

void ServerPacketManager::startServer()
{
	socketManager.startServer();
}

void ServerPacketManager::stopServer()
{
	socketManager.stopServer();
}

void ServerPacketManager::handleClients()
{
	socketManager.receivePackets();
	socketManager.sendWaitingPackets();
}

void ServerPacketManager::broadcastEntityModel(EntityModel & em)
{
	sf::Packet packet;
	sf::Uint8 code = Common::ENTITYPOS;
	packet << code << em;
	socketManager.sendPacket(0,packet);
}

void ServerPacketManager::broadcastLevelCompleted(sf::Uint16 id)
{
	sf::Packet packet;
	sf::Uint8 code = Common::LEVELCOMPLETED;
	packet << code << id;
	socketManager.sendPacket(0, packet);
}

void ServerPacketManager::sendSeedDimension(MazeConfig config)
{
	sf::Packet packet;
	sf::Uint8 code = Common::GENERATELEVEL;
	packet << code << config;
	socketManager.sendPacket(0, packet);
}

void ServerPacketManager::broadcastName(sf::Uint16 id, sf::String name)
{
	sf::Packet packet;
	sf::Uint8 code = Common::NAME;
	packet << code << id << name;
	socketManager.sendPacket(0, packet);
}



