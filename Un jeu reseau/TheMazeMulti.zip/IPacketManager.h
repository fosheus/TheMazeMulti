#pragma once
#include <SFML\Network.hpp>
#include "EntityModel.h"
#include "MazeConfig.h"
#include <vector>
class IPacketManager
{
public:
	virtual void packetReceived(sf::Packet& packet) = 0;
	virtual void lostConnection() = 0;

private :
	virtual sf::Uint16 welcomeReceived(sf::Packet& packet) = 0;
	virtual std::vector<EntityModel> entityPosReceived(sf::Packet& packet) = 0;
	virtual int newGameReceived(sf::Packet& packet) = 0;
	virtual void startGameReceived(sf::Packet& packet) = 0;
	virtual MazeConfig generateLevelReceived(sf::Packet& packet) = 0;
	//TODO
	virtual int eventReceived(sf::Packet& packet) = 0;
	virtual sf::Uint16 levelCompletedReceived(sf::Packet& packet) = 0;
	virtual int levelGeneratedReceived(sf::Packet& packet) = 0;
	virtual int disconnectReceived(sf::Packet& packet) = 0;
	virtual std::pair<sf::Uint16, sf::String> nameReceived(sf::Packet & packet) = 0;
	
};

